#include <iostream>
#include <string>
#include <vector>
#include <cxxopts.hpp> // Biblioteca para parsing de argumentos
#include "core/apk_builder.h" // Caminho correto do header
#include "shared/apk_config.h"

int main(int argc, char* argv[]) {
    cxxopts::Options options(argv[0], "Gerador de APK para Android Stream Manager");

    try {
        options.add_options()
            ("h,help", "Mostrar esta mensagem de ajuda")
            ("app-name", "Nome do aplicativo (ex: 'Meu App')", cxxopts::value<std::string>())
            ("pkg-name", "Nome do pacote (ex: 'com.exemplo.meuapp')", cxxopts::value<std::string>())
            ("server-url", "URL do servidor de streaming", cxxopts::value<std::string>())
            ("server-port", "Porta do servidor de streaming", cxxopts::value<int>()->default_value("8443"))
            ("version-name", "Versão do app (ex: '1.0.0')", cxxopts::value<std::string>()->default_value("1.0.0"))
            ("version-code", "Código da versão do app", cxxopts::value<int>()->default_value("1"))
            ("debug", "Habilitar modo de depuração", cxxopts::value<bool>()->default_value("false"))
        ;

        auto result = options.parse(argc, argv);

        if (result.count("help")) {
            std::cout << options.help() << std::endl;
            return 0;
        }

        AndroidStreamManager::ApkConfig config;

        // Validação de argumentos obrigatórios
        if (!result.count("app-name") || !result.count("pkg-name") || !result.count("server-url")) {
            std::cerr << "Erro: Os argumentos --app-name, --pkg-name e --server-url são obrigatórios." << std::endl;
            std::cerr << options.help() << std::endl;
            return 1;
        }

        // Preencher a configuração a partir dos argumentos
        config.appName = result["app-name"].as<std::string>();
        config.packageName = result["pkg-name"].as<std::string>();
        config.serverUrl = result["server-url"].as<std::string>();
        config.serverPort = result["server-port"].as<int>();
        config.versionName = result["version-name"].as<std::string>();
        config.versionCode = result["version-code"].as<int>();
        config.enableDebug = result["debug"].as<bool>();

        // Adicionar permissões padrão
        config.addCommonPermissions();

        std::cout << "Iniciando o gerador de APK com a configuração fornecida..." << std::endl;

        // Usar caminhos padrão se não fornecidos
        std::string sdkPath = "/usr/lib/android-sdk";
        std::string templatePath = "android-client-template";

        AndroidStreamManager::ApkBuilder builder(sdkPath, templatePath);
        AndroidStreamManager::BuildResult result_build = builder.buildApk(config);

        if (result_build.success) {
            std::cout << "APK gerado com sucesso em: " << result_build.apkPath << std::endl;
        } else {
            std::cerr << "Erro ao gerar APK: " << result_build.errorMessage << std::endl;
        }

        std::cout << "Processo do gerador de APK concluído." << std::endl;

    } catch (const cxxopts::exceptions::exception& e) {
        std::cerr << "Erro ao processar argumentos: " << e.what() << std::endl;
        std::cerr << options.help() << std::endl;
        return 1;
    }

    return 0;
}
