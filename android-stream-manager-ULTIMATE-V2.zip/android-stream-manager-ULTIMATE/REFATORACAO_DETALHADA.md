# Refatoração Profunda: Android Stream Manager (v1.1.0)

Este projeto passou por uma revitalização completa para resolver problemas estruturais, de compilação e de arquitetura. Abaixo estão os detalhes das melhorias implementadas.

## 1. Infraestrutura de Build (CMake Moderno)
O sistema de build foi totalmente reescrito para seguir as melhores práticas do CMake moderno:
- **FetchContent Centralizado**: Todas as dependências externas (`uWebSockets`, `lz4`, `libzip`, `jwt-cpp`, `nlohmann_json`, `cxxopts`) são gerenciadas automaticamente via CMake. Não é mais necessário instalar bibliotecas manualmente no sistema.
- **Targets Modulares**: O projeto agora é dividido em uma biblioteca estática central (`android_stream_lib`) e executáveis independentes (`stream_server`, `apk_builder`).
- **Suporte Multiplataforma**: Adicionada detecção e tratamento para builds em Linux e Windows.

## 2. Correções de Código e Estabilidade
- **Sincronização de Arquivos**: Corrigidos todos os erros de "arquivo não encontrado" no CMake, garantindo que todos os módulos (`optimization`, `monitoring`, `security`) estejam corretamente linkados.
- **MetricsCollector**: Corrigido erro de compilação em sistemas Linux (membro `f_bavail` no `statvfs`) e adicionados construtores padrão necessários para uso em containers STL.
- **Base64**: Integrada implementação nativa de Base64 para suportar codificação de payloads binários no protocolo.

## 3. Arquitetura do Sistema
O projeto agora possui uma separação clara de responsabilidades:
- **Core**: Gerenciamento de sistema, dispositivos e lógica de build de APKs.
- **Optimization**: Thread pool customizado e otimizador de stream para redução de latência.
- **Security**: Gerenciamento de tokens JWT e criptografia TLS 1.3 (via OpenSSL 3.0).
- **Monitoring**: Coletor de métricas compatível com Prometheus e sistema de alertas de saúde.

## 4. Como Compilar e Executar

### Pré-requisitos
- CMake 3.16+
- Compilador C++17 (GCC 9+, Clang 10+, MSVC 2019+)
- OpenSSL Development Headers

### Build
```bash
mkdir build && cd build
cmake .. -DBUILD_DASHBOARD=OFF
make -j$(nproc)
```

### Executáveis Gerados
- `bin/stream_server`: O servidor central de streaming.
- `bin/apk_builder`: Ferramenta CLI para gerar novos clientes Android.

## 5. Próximos Passos Recomendados
1. **Dashboard**: Para habilitar o Dashboard Qt, instale o Qt6 e as bibliotecas de desenvolvimento do FFmpeg (`libavcodec-dev`, etc).
2. **Integração Android**: O `apk_builder` está pronto para ser integrado com um `ANDROID_SDK_ROOT` real para automação completa de CI/CD.
