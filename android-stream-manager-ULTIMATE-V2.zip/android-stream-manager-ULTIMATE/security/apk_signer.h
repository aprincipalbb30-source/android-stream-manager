#ifndef APK_SIGNER_H
#define APK_SIGNER_H

#include <string>
#include <vector>
#include <memory>
#include <chrono>
#include <mutex>
#include <unordered_map>
#include <openssl/pkcs7.h>
#include <openssl/x509.h>

namespace AndroidStreamManager {

/**
 * @class ApkSigner
 * @brief Handles the signing of APK files using provided certificates and keys.
 *
 * This class provides functionalities to sign an Android application package (APK)
 * using the APK Signature Scheme v2. It also includes a utility to generate
 * a Java Keystore (JKS) for signing purposes.
 */
class ApkSigner {
public:
    ApkSigner();
    ~ApkSigner();

    /**
     * @brief Signs an APK file with a given certificate and private key.
     * @param apkPath Path to the input APK file.
     * @param certPem The certificate in PEM format.
     * @param privateKeyPem The private key in PEM format.
     * @param outputPath Path for the signed output APK file.
     * @return True if signing is successful, false otherwise.
     */
    bool signWithKeys(const std::string& apkPath,
                      const std::string& certPem,
                      const std::string& privateKeyPem,
                      const std::string& outputPath);

    /**
     * @brief Generates a new Java Keystore (JKS).
     * @param path The path where the keystore will be saved.
     * @param password The password for the keystore.
     * @param alias The alias for the key pair.
     * @param dname The distinguished name for the certificate (e.g., "CN=My App, OU=Dev, O=My Org, C=US").
     * @param validityYears The validity period of the certificate in years.
     * @return True if keystore generation is successful, false otherwise.
     */
    bool generateKeystore(const std::string& path,
                          const std::string& password,
                          const std::string& alias,
                          const std::string& dname,
                          int validityYears);

private:
    class Impl;
    std::unique_ptr<Impl> pImpl;
};

/**
 * @class CorporateSigningManager
 * @brief Manages corporate-level build signing and verification.
 *
 * This singleton class is responsible for creating digital signatures for builds,
 * ensuring the integrity and authenticity of each build artifact. It uses a master
 * key for signing and maintains a history of all signatures.
 */
class CorporateSigningManager {
public:
    struct SignatureRecord {
        std::string buildId;
        std::string apkHash;
        std::string operatorId;
        std::string signature;
        std::chrono::system_clock::time_point timestamp;
    };

    static CorporateSigningManager& getInstance();

    void initialize(const std::string& masterKeyPath,
                    const std::string& certChainPath);

    std::string signBuild(const std::string& buildId,
                          const std::string& apkHash,
                          const std::string& operatorId);

private:
    CorporateSigningManager() = default;
    ~CorporateSigningManager() = default;
    CorporateSigningManager(const CorporateSigningManager&) = delete;
    CorporateSigningManager& operator=(const CorporateSigningManager&) = delete;

    // Funções utilitárias para conversão de tempo
    std::string timePointToString(const std::chrono::system_clock::time_point& tp);
    std::chrono::system_clock::time_point stringToTimePoint(const std::string& timeStr);

    // Funções de execução de query com parâmetros
    std::vector<std::unordered_map<std::string, std::string>>
    executeSelect(const std::string& query, const std::vector<std::string>& params);
    bool executeQuery(const std::string& query, const std::vector<std::string>& params);

    std::string masterKey;
    std::vector<SignatureRecord> history;
    std::mutex mutex;
};

} // namespace AndroidStreamManager

#endif // APK_SIGNER_H