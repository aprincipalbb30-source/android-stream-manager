#!/bin/bash

# Android Stream Manager ULTIMATE - Inicializador Completo
# Inicia o Servidor de Stream em background e o Dashboard

# Obter o diretório onde o script está localizado
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
BIN_DIR="$SCRIPT_DIR/build/bin"

echo "Iniciando Android Stream Manager ULTIMATE..."

# Verificar se os binários existem
if [ ! -f "$BIN_DIR/stream_server" ] || [ ! -f "$BIN_DIR/android_stream_dashboard" ]; then
    echo "Erro: Binários não encontrados em $BIN_DIR. Por favor, execute o instalador primeiro."
    exit 1
fi

# Iniciar o Stream Server em background se não estiver rodando
if ! pgrep -x "stream_server" > /dev/null; then
    echo "Iniciando Stream Server..."
    "$BIN_DIR/stream_server" > /dev/null 2>&1 &
    sleep 2
else
    echo "Stream Server já está em execução."
fi

# Iniciar o Dashboard
echo "Iniciando Dashboard..."
"$BIN_DIR/android_stream_dashboard"
