#ifndef SYSTEM_MANAGER_H
#define SYSTEM_MANAGER_H

#include <string>
#include <atomic>
#include <chrono>
#include <memory>
#include <unordered_map>
#include "security/apk_signer.h"
#include "compliance/compliance_manager.h"
#include "optimization/thread_pool.h"
#include "optimization/build_cache.h"
#include "optimization/stream_optimizer.h"
#include "database/database_manager.h"
#include "monitoring/metrics_collector.h"
#include "monitoring/alerts_manager.h"
#include "monitoring/health_checker.h"
#include "monitoring/prometheus_exporter.h"
#include "core/apk_builder.h" // Incluir para BuildResult

// Forward declarations para evitar includes circulares e desnecessários no header
namespace AndroidStreamManager { class SecureTlsClient; }
struct ApkConfig; // Já está em apk_builder.h, mas pode ser mantido por clareza

// Definição temporária para StreamData, idealmente viria de um header compartilhado
struct StreamData {
    std::vector<uint8_t> data;
    // Outros metadados do stream
};

namespace AndroidStreamManager {

class SystemManager {
public:
    static SystemManager& getInstance();
    
    bool initialize(const std::string& configPath);
    void shutdown();
    
    // Componentes do sistema
    ThreadPool& getThreadPool() { return threadPool; }
    BuildCache& getBuildCache() { return buildCache; }
    StreamOptimizer& getStreamOptimizer() { return streamOptimizer; }
    
    // Segurança
    bool validateSession(const std::string& token,
                        const std::string& deviceId);
    
    // Build com cache
    BuildResult buildApkWithCache(const ApkConfig& config,
                                 const std::string& operatorId);
    
    // Streaming otimizado
    bool streamData(const std::string& deviceId,
                   StreamData& data);
    
    // Estatísticas do sistema
    struct SystemStats {
        size_t activeSessions;
        size_t buildsInCache;
        size_t threadsActive;
        double cacheHitRate;
        std::chrono::seconds uptime;

        // Estatísticas do database
        size_t totalDevices;
        size_t activeDevices;
        size_t totalAuditLogs;
        size_t databaseSizeBytes;
    };
    
    SystemStats getStats() const;
    
private:
    SystemManager();
    ~SystemManager();
    
    // Componentes
    ThreadPool threadPool;
    BuildCache buildCache;
    StreamOptimizer streamOptimizer;

    // Monitoramento
    MetricsCollector& metricsCollector;
    AlertsManager& alertsManager;
    HealthChecker& healthChecker;
    PrometheusExporter prometheusExporter;
    
    // Estado do sistema
    std::atomic<bool> initialized{false};
    std::chrono::system_clock::time_point startTime;
    
    // Sessões ativas
    struct ActiveSession {
        std::string deviceId;
        std::string operatorId;
        std::chrono::system_clock::time_point startedAt;
        std::shared_ptr<AndroidStreamManager::SecureTlsClient> connection;
    };
    
    std::unordered_map<std::string, ActiveSession> activeSessions;
    mutable std::mutex sessionsMutex;

    // Caminhos para o builder
    std::string androidSdkPath;
    std::string templatePath;
};

} // namespace AndroidStreamManager

#endif // SYSTEM_MANAGER_H