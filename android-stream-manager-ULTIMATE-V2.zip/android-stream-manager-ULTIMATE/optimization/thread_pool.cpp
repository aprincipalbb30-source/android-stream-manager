#include "thread_pool.h"

#include <iostream>
#include <algorithm>
#include <chrono>

namespace AndroidStreamManager {

ThreadPool::ThreadPool(size_t numThreads)
    : stop_(false),
      activeThreads_(0),
      totalTasksProcessed_(0),
      failedTasks_(0),
      totalTaskTime_(std::chrono::microseconds(0)),
      minTaskTime_(std::chrono::microseconds(0)),
      maxTaskTime_(std::chrono::microseconds(0)) {

    size_t hardwareThreads = std::thread::hardware_concurrency();
    if (hardwareThreads == 0) {
        hardwareThreads = 4;
    }

    numThreads = std::min(numThreads, hardwareThreads * 2);

    std::cout << "ThreadPool inicializado com " << numThreads
              << " threads (hardware: " << hardwareThreads << ")"
              << std::endl;

    for (size_t i = 0; i < numThreads; ++i) {
        workers_.emplace_back([this, i]() {
            workerThread(i);
        });
    }
}

ThreadPool::~ThreadPool() {
    shutdown();
    std::cout << "ThreadPool destruído" << std::endl;
}

void ThreadPool::shutdown() {
    {
        std::unique_lock<std::mutex> lock(queueMutex_);
        if (stop_) {
            return;
        }
        stop_ = true;
    }

    condition_.notify_all();

    for (std::thread& worker : workers_) {
        if (worker.joinable()) {
            worker.join();
        }
    }

    workers_.clear();
}

size_t ThreadPool::getActiveThreads() const {
    std::lock_guard<std::mutex> lock(statsMutex_);
    return activeThreads_;
}

size_t ThreadPool::getQueuedTasks() const {
    std::lock_guard<std::mutex> lock(queueMutex_);
    return tasks_.size();
}

ThreadPoolStats ThreadPool::getStatistics() const {
    std::lock_guard<std::mutex> lock(statsMutex_);

    ThreadPoolStats stats;
    stats.totalThreads = workers_.size();
    stats.activeThreads = activeThreads_;
    stats.queuedTasks = getQueuedTasks();
    stats.totalTasksProcessed = totalTasksProcessed_;

    if (totalTasksProcessed_ > 0) {
        stats.averageTaskTime =
            std::chrono::duration_cast<std::chrono::microseconds>(
                totalTaskTime_ / totalTasksProcessed_);
    } else {
        stats.averageTaskTime = std::chrono::microseconds(0);
    }

    stats.minTaskTime = minTaskTime_;
    stats.maxTaskTime = maxTaskTime_;
    stats.failedTasks = failedTasks_;

    return stats;
}

void ThreadPool::setMaxThreads(size_t /*maxThreads*/) {
    std::cout << "Aviso: setMaxThreads não implementado." << std::endl;
    std::cout << "Reinicie o ThreadPool para alterar o número de threads."
              << std::endl;
}

void ThreadPool::waitForAllTasks() {
    std::unique_lock<std::mutex> lock(queueMutex_);
    waitCondition_.wait(lock, [this]() {
        return tasks_.empty() && activeThreads_ == 0;
    });
}

bool ThreadPool::isIdle() const {
    std::lock_guard<std::mutex> lock(queueMutex_);
    return tasks_.empty() && activeThreads_ == 0;
}

void ThreadPool::workerThread(size_t threadId) {
    std::cout << "Worker thread " << threadId << " iniciada" << std::endl;

    while (true) {
        std::function<void()> task;

        {
            std::unique_lock<std::mutex> lock(queueMutex_);
            condition_.wait(lock, [this]() {
                return stop_ || !tasks_.empty();
            });

            if (stop_ && tasks_.empty()) {
                break;
            }

            task = std::move(tasks_.front());
            tasks_.pop();
        }

        executeTask(task, threadId);
    }

    std::cout << "Worker thread " << threadId << " finalizada" << std::endl;
}

void ThreadPool::executeTask(std::function<void()> task, size_t threadId) {
    auto startTime = std::chrono::high_resolution_clock::now();

    {
        std::lock_guard<std::mutex> lock(statsMutex_);
        ++activeThreads_;
    }

    try {
        task();
    } catch (const std::exception& e) {
        std::cerr << "Exceção em worker thread "
                  << threadId << ": " << e.what() << std::endl;
        std::lock_guard<std::mutex> lock(statsMutex_);
        ++failedTasks_;
    } catch (...) {
        std::cerr << "Exceção desconhecida em worker thread "
                  << threadId << std::endl;
        std::lock_guard<std::mutex> lock(statsMutex_);
        ++failedTasks_;
    }

    auto endTime = std::chrono::high_resolution_clock::now();
    auto taskDuration =
        std::chrono::duration_cast<std::chrono::microseconds>(
            endTime - startTime);

    {
        std::lock_guard<std::mutex> lock(statsMutex_);
        --activeThreads_;
        ++totalTasksProcessed_;
        totalTaskTime_ += taskDuration;

        if (minTaskTime_.count() == 0 || taskDuration < minTaskTime_) {
            minTaskTime_ = taskDuration;
        }
        if (taskDuration > maxTaskTime_) {
            maxTaskTime_ = taskDuration;
        }
    }

    waitCondition_.notify_all();
}

} // namespace AndroidStreamManager
