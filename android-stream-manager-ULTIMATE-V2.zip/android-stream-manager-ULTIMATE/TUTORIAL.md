# Tutorial: Android Stream Manager ULTIMATE

Este guia fornece instruções detalhadas sobre como configurar, compilar e utilizar o **Android Stream Manager ULTIMATE** no ambiente Linux (incluindo VMware).

## 📋 Requisitos do Sistema

* **Sistema Operacional:** Ubuntu 22.04 LTS ou superior (recomendado).
* **Hardware:** Mínimo de 4GB RAM (8GB recomendado para VMs).
* **Dependências:** Qt6, FFmpeg, JDK 17, Android SDK Platform Tools.

---

## 🚀 Instalação e Compilação

Para instalar todas as dependências e compilar o projeto automaticamente, utilize o script fornecido:

```bash
chmod +x install_linux.sh
sudo ./install_linux.sh
```

O script irá:
1. Instalar todos os pacotes `qt6-*` e bibliotecas de desenvolvimento necessárias.
2. Configurar as ferramentas de decodificação de vídeo (FFmpeg).
3. Compilar os três componentes principais:
   * **Dashboard:** Interface gráfica em Qt.
   * **Stream Server:** Servidor de streaming em C++.
   * **APK Builder:** Ferramenta de geração de APKs customizados.

---

## 🎮 Como Usar

### 1. Iniciando o Sistema
Você tem três formas de iniciar o sistema:
1.  **Atalho na Área de Trabalho:** Clique duas vezes no ícone "Android Stream Manager".
2.  **Comando no Terminal:** Digite `asm-start` em qualquer terminal.
3.  **Script Direto:** Execute `./start_system.sh` na pasta do projeto.

### ⌨️ Atalhos de Terminal (Aliases)
O instalador adiciona comandos úteis ao seu `.bashrc`:
*   `asm-start`: Inicia o Servidor de Stream e o Dashboard simultaneamente.
*   `asm-build`: Recompila o projeto rapidamente.
*   `asm-logs`: Monitora os logs do servidor em tempo real.
*   `asm-clean`: Limpa os arquivos temporários de compilação.

### 2. Gerando um APK Customizado
No Dashboard, navegue até a aba **Configuração de APK**:
* Preencha o nome do aplicativo.
* Defina o IP/Host do servidor onde o stream será enviado.
* Selecione as permissões desejadas (Câmera, Microfone, Persistência).
* Clique em **Gerar APK**. O sistema usará o `apk_builder` para criar um arquivo pronto para instalação.

### 3. Monitoramento e Streaming
* Conecte um dispositivo Android via USB (com depuração USB ativada).
* O dispositivo aparecerá na lista lateral.
* Clique em **Iniciar Streaming** para ver a tela do dispositivo em tempo real.
* Use a aba **Monitoramento** para acompanhar o uso de CPU, Memória e alertas de segurança.

---

## 🛠 Solução de Problemas (VMware)

Se você encontrar problemas de performance ou falhas gráficas no VMware:
1. **Aceleração 3D:** Certifique-se de que "Accelerate 3D graphics" está ativado nas configurações da VM.
2. **Memória de Vídeo:** Aumente a memória de vídeo para pelo menos 256MB.
3. **Erros de Qt:** Se a interface não abrir, tente executar com:
   `export QT_X11_NO_MITSHM=1` antes de iniciar o binário.

---

## 💎 Sugestões de Melhorias na Interface Qt

Durante a análise técnica, identificamos os seguintes pontos para evolução da interface:

| Área | Melhoria Sugerida | Benefício |
| :--- | :--- | :--- |
| **Estilização** | Implementação de **QSS (Qt Style Sheets)** com tema Dark/Moderno. | Visual profissional e menos cansativo. |
| **UX** | Adição de **Drag & Drop** para instalação de APKs. | Facilidade de uso e agilidade. |
| **Gráficos** | Migração de QCharts para **Qt Quick/QML** na parte de monitoramento. | Animações mais fluidas e interface responsiva. |
| **Notificações** | Sistema de **Tray Notifications** nativo. | Alertas mesmo com a janela minimizada. |

---

**Suporte:** Para mais informações, consulte a documentação técnica na pasta `docs/`.
