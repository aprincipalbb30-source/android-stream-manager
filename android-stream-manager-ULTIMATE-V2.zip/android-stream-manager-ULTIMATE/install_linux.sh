#!/bin/bash

# Android Stream Manager ULTIMATE - Instalador para Linux
# Desenvolvido para máxima compatibilidade em VMs e sistemas Ubuntu/Debian

set -e

# Cores para saída
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}   Android Stream Manager ULTIMATE - Installer    ${NC}"
echo -e "${BLUE}==================================================${NC}"

# 1. Verificar privilégios
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Por favor, execute como root (sudo ./install_linux.sh)${NC}"
  exit 1
fi

# 2. Instalar dependências do sistema
echo -e "\n${BLUE}[1/4] Instalando dependências do sistema...${NC}"
apt-get update
apt-get install -y \
    build-essential \
    cmake \
    git \
    qt6-base-dev \
    qt6-websockets-dev \
    qt6-multimedia-dev \
    libqt6charts6-dev \
    libavcodec-dev \
    libavformat-dev \
    libswscale-dev \
    libavutil-dev \
    liblz4-dev \
    libzip-dev \
    openjdk-17-jdk \
    android-sdk-platform-tools

# 3. Preparar diretório de build
echo -e "\n${BLUE}[2/4] Preparando ambiente de compilação...${NC}"
BUILD_DIR="build"
if [ -d "$BUILD_DIR" ]; then
    rm -rf "$BUILD_DIR"
fi
mkdir "$BUILD_DIR"
cd "$BUILD_DIR"

# 4. Compilar o projeto
echo -e "\n${BLUE}[3/4] Compilando o projeto...${NC}"
cmake ..
make -j$(nproc)

# 5. Finalizar instalação
echo -e "\n${BLUE}[4/5] Criando atalhos na área de trabalho...${NC}"
# Obter o diretório real do projeto (pai do diretório build atual)
PROJECT_DIR="$(cd .. && pwd)"
USER_HOME=$(eval echo "~$SUDO_USER")
DESKTOP_DIR="$USER_HOME/Desktop"

# Se o diretório Desktop não existir (idioma diferente), tenta "Área de Trabalho"
if [ ! -d "$DESKTOP_DIR" ]; then
    DESKTOP_DIR="$USER_HOME/Área de Trabalho"
fi

# Criar arquivo .desktop
cat <<EOF > "$DESKTOP_DIR/AndroidStreamManager.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=Android Stream Manager
Comment=Gerenciador de Streaming Android ULTIMATE
Exec=$PROJECT_DIR/start_system.sh
Icon=$PROJECT_DIR/dashboard/icons/devices.png
Terminal=false
Categories=Utility;Development;
EOF

# Dar permissões ao atalho
chown $SUDO_USER:$SUDO_USER "$DESKTOP_DIR/AndroidStreamManager.desktop"
chmod +x "$DESKTOP_DIR/AndroidStreamManager.desktop"

echo -e "\n${BLUE}[5/5] Adicionando atalhos ao .bashrc...${NC}"
BASHRC="$USER_HOME/.bashrc"
# Evitar duplicatas
sed -i '/# Android Stream Manager ULTIMATE/d' "$BASHRC"
sed -i '/alias asm-/d' "$BASHRC"

cat <<EOF >> "$BASHRC"

# Android Stream Manager ULTIMATE Aliases
alias asm-start='$PROJECT_DIR/start_system.sh'
alias asm-build='cd $PROJECT_DIR/build && make -j\$(nproc)'
alias asm-logs='tail -f $PROJECT_DIR/build/bin/stream_server.log'
alias asm-clean='rm -rf $PROJECT_DIR/build/*'
EOF

echo -e "${GREEN}Build e configuração de atalhos concluídos com sucesso!${NC}"

echo -e "\n${BLUE}==================================================${NC}"
echo -e "${GREEN}   Instalação concluída!${NC}"
echo -e "Atalho criado em: $DESKTOP_DIR"
echo -e "Novos comandos disponíveis no terminal (após reiniciar ou 'source ~/.bashrc'):"
echo -e "  ${BLUE}asm-start${NC}   - Inicia o sistema completo"
echo -e "  ${BLUE}asm-build${NC}   - Recompila o projeto"
echo -e "  ${BLUE}asm-logs${NC}    - Visualiza logs do servidor"
echo -e "  ${BLUE}asm-clean${NC}   - Limpa o diretório de build"
echo -e "${BLUE}==================================================${NC}"
